class Config:
    SECRET_KEY = "your_secret_key"
    DEBUG = True